package com.cesarsicas.domain;

public class MyClass {
}
